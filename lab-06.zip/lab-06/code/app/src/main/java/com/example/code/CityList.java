package com.example.code;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.List;

/**
 * This class holds the city type objects in a list
 * and provides operations to manage the collection of cities.
 */
public class CityList {
    private List<City> cities = new ArrayList<>();

    /**
     * This method adds a city object to the cities list
     * @param city
     *          This is a City object we want to add to the List
     * @throws IllegalArgumentException if the city already exists in the list
     */
    public void add(City city){
        if(cities.contains(city))
            throw new IllegalArgumentException();
        cities.add(city);
    }

    /**
     * This method sorts the list of cities
     * @return a sorted list of cities
     */
    public List<City> getCities(){
        List<City> list = cities;
        Collections.sort(list);
        return list;
    }

    /**
     * Checks if the specified city exists in the list
     * @param city the city to check for existence in the list
     * @return true if the city exists in the list, false otherwise
     */
    public boolean hasCity(City city) {
        return cities.contains(city);
    }

    /**
     * Deletes the specified city from the list
     * @param city the city to be deleted from the list
     * @throws IllegalArgumentException if the city is not found in the list
     */
    public void delete(City city) {
        if (!cities.contains(city)) {
            throw new IllegalArgumentException("City not found in the list");
        }
        cities.remove(city);
    }

    /**
     * Returns the number of cities in the list
     * @return the count of cities in the list
     */
    public int countCities() {
        return cities.size();
    }
}