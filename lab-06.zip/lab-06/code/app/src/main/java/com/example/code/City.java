package com.example.code;

/**
 * This class represents a City with a name and province
 */
public class City implements Comparable<City> {
    private String city;
    private String province;

    /**
     * Constructs a new City with the specified name and province
     * @param name the name of the city
     * @param province the province where the city is located
     */
    public City(String name, String province) {
        this.city = name;
        this.province = province;
    }

    /**
     * Gets the city name
     * @return the name of the city
     */
    public String getCity() {
        return city;
    }

    /**
     * Sets the city name
     * @param name the new name for the city
     */
    public void setCity(String name) {
        this.city = name;
    }

    /**
     * Gets the province name
     * @return the name of the province
     */
    public String getProvince() {
        return province;
    }

    /**
     * Sets the province name
     * @param province the new province name
     */
    public void setProvince(String province) {
        this.province = province;
    }

    /**
     * Compares this city to another city for ordering
     * @param o the city to be compared
     * @return 0 if equal, negative if this city comes before, positive if after
     */
    @Override
    public int compareTo(City o) {
        return this.city.compareTo(o.getCity());
    }

    /**
     * Checks equality with another object
     * @param obj the object to compare with
     * @return true if the cities have the same name and province, false otherwise
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        City cityObj = (City) obj;
        return this.city.equals(cityObj.city) && this.province.equals(cityObj.province);
    }

    /**
     * Generates hash code for the city object
     * @return the hash code value
     */
    @Override
    public int hashCode() {
        int result = city.hashCode();
        result = 31 * result + province.hashCode();
        return result;
    }
}