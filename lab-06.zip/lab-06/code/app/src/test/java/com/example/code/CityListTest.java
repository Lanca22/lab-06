package com.example.code;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for CityList class
 */
public class CityListTest {

    /**
     * Creates a mock City object for testing
     * @return a City object with name "Edmonton" and province "AB"
     */
    public City mockCity(){
        return new City("Edmonton", "AB");
    }

    /**
     * Creates a mock CityList with one city for testing
     * @return a CityList containing one mock city
     */
    public CityList mockCityList(){
        CityList cityList = new CityList();
        cityList.add(mockCity());
        return cityList;
    }

    @Test
    public void testAdd(){
        CityList cityList = mockCityList();
        assertEquals(1,cityList.getCities().size());
        City c = new City("Regina", "SK");
        cityList.add(c);
        assertEquals(2,cityList.getCities().size());
        assertTrue(cityList.getCities().contains(c));
    }

    @Test
    void testGetCities(){
        CityList cityList = mockCityList();
        assertEquals(0,mockCity().compareTo(cityList.getCities().get(0)));
        City c = new City("Charlottetown", "PEI");
        cityList.add(c);
        assertEquals(0, c.compareTo(cityList.getCities().get(0)));
        assertEquals(0,mockCity().compareTo(cityList.getCities().get(1)));
    }

    @Test
    void testHasCity() {
        CityList cityList = mockCityList();
        City existingCity = mockCity();
        City newCity = new City("Vancouver", "BC");

        assertTrue(cityList.hasCity(existingCity));

        assertFalse(cityList.hasCity(newCity));

        cityList.add(newCity);
        assertTrue(cityList.hasCity(newCity));
    }

    @Test
    void testDelete() {
        CityList cityList = mockCityList();
        City existingCity = mockCity();
        City newCity = new City("Toronto", "ON");

        cityList.delete(existingCity);
        assertEquals(0, cityList.countCities());
        assertFalse(cityList.hasCity(existingCity));

        cityList.add(existingCity);
        cityList.add(newCity);
        assertEquals(2, cityList.countCities());

        cityList.delete(newCity);
        assertEquals(1, cityList.countCities());
        assertFalse(cityList.hasCity(newCity));
        assertTrue(cityList.hasCity(existingCity));
    }

    @Test
    void testDeleteThrowsException() {
        CityList cityList = mockCityList();
        City nonExistingCity = new City("Montreal", "QC");

        assertThrows(IllegalArgumentException.class, () -> {
            cityList.delete(nonExistingCity);
        });
    }

    @Test
    void testCountCities() {
        CityList cityList = new CityList();

        assertEquals(0, cityList.countCities());

        cityList.add(mockCity());
        assertEquals(1, cityList.countCities());

        cityList.add(new City("Calgary", "AB"));
        assertEquals(2, cityList.countCities());

        cityList.delete(mockCity());
        assertEquals(1, cityList.countCities());
    }
}